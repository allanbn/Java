/**
 * 
 */
package domain;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/**
 * @author alysson.l.ribeiro
 *
 */
public class Grafo {

	private List<String> vertices = new ArrayList<String>();	
	private List<String> arestas = new ArrayList<String>();
	private int[][] MatrizAdjacencia;
	
	/**
	 * Construtor simples
	 * @author alysson.l.ribeiro
	 */
	public Grafo() {
		super();
	}

	/**
	 * Construtor com parametros
	 * @author alysson.l.ribeiro
	 * @param vertices
	 * @param arestas
	 */
	public Grafo(String[] vertices, String[] arestas) {
		super();
					
		for (String v:vertices) {
			this.adicionaVertice(v.trim());
		}
		
		// INICIALIZA UMA MATRIZ DE ADJACENCIA QUE SER� PREENCHIDA AO ADICIONAR AS ARESTAS
		int[][] auxMatrizAdjacencia = new int[this.vertices.size()][this.vertices.size()];
		
		for (String a:arestas) {
			this.adicionaAresta(a.trim(), auxMatrizAdjacencia);

		}
		
		// CRIA MATRIZ DE ADJACENCIA APOS TODAS AS ARESTAS E VERTICES TEREM SIDO CRIADOS COM SUCESSO
		this.setMatrizAdjacencia(auxMatrizAdjacencia);
	}
	
	/**
	 * Recebe o nome e dois v�rtices no qual deve ser criado uma aresta.
	 * @author alysson.l.ribeiro
	 */
	public void adicionaAresta(String a, int[][] matrizAdjacencia) {
		if (verificaAresta(a)) {
			
			String nomeAresta = this.getNomeAresta(a);
			String verticeOrigem = this.getVerticesAresta(a).get(0);
			String verticeDestino = this.getVerticesAresta(a).get(1);
			
			if (!nomeAresta.isEmpty() && verticeExiste(verticeOrigem) && verticeExiste(verticeDestino)) {
				this.arestas.add(a);
				System.out.println("Aresta " + a + " adicionada.");
				
				//Adiciona aresta na matriz de adjacencia
				if (verticeOrigem.equals(verticeDestino)) {
					matrizAdjacencia[vertices.indexOf(verticeOrigem) ][vertices.indexOf(verticeDestino)] += 1;
				} else {
					matrizAdjacencia[vertices.indexOf(verticeOrigem) ][vertices.indexOf(verticeDestino)] += 1;
					matrizAdjacencia[vertices.indexOf(verticeDestino)][vertices.indexOf(verticeOrigem) ] += 1;
				}
			} 			
		} 		
	}
	
	/**
	 * Adiciona um vertice ao grafo caso n�o exista outro vertice igual e o mesmo seja valido
	 * @author alysson.l.ribeiro
	 * @param vertice a ser adicionado
	 */
	public void adicionaVertice(String v) {
		if (verificaValidadeVertice(v)){
			vertices.add(v);
			System.out.println("Vertice " + v + " adicionado.");
		}
	}
	
	/**
	 * @return the vertices
 	 * @author alysson.l.ribeiro
	 */
	public List<String> getVertices() {
		return this.vertices;
	}
	
	/**
	 * @return the matrizAdjacencia
	 */
	public int[][] getMatrizAdjacencia() {
		return MatrizAdjacencia;
	}

	/**
	 * @param matrizAdjacencia the matrizAdjacencia to set
	 */
	public void setMatrizAdjacencia(int[][] matrizAdjacencia) {
		MatrizAdjacencia = matrizAdjacencia;
	}

	/**
	 * @return the arestas
	 * @author alysson.l.ribeiro
	 */
	public List<String> getArestas() {
		return this.arestas;
	}
	
	/**
	 * @return arestas de um vertice no grafo, caso exista
	 */
	public List<String> getArestas(String v) {
		List<String> arestasvertice = new ArrayList<String>();

		if (verticeExiste(v)) {
			
			for (String a:this.arestas){
				String verticeOrigem = this.getVerticesAresta(a).get(0);
				
				if (v.equals(verticeOrigem)) {
					arestasvertice.add(a);
				}
			}	
			
		} else {			
			System.out.println("Vertice nao existe.");
		}
		
		return arestasvertice;
	}
	
	/**
	 * Recupera os vertices de uma determinada aresta
	 * @author alysson.l.ribeiro
	 * @return os vertices de uma aresta, onde o indice 0 = Origem e indice 1 = Destino
	 */
	public List<String> getVerticesAresta(String a) {
		
		List<String> vertices = new ArrayList<String>();
		
		String verticeOrigem = a.substring(a.indexOf("(") + 1, a.indexOf("-"));
		String verticeDestino = a.substring(a.indexOf("-") + 1, a.indexOf(")"));
		
		vertices.add(verticeOrigem);
		vertices.add(verticeDestino);

		return vertices;
	}
	
	/**
	 * Recupera o nome de uma determinada aresta
	 * @author alysson.l.ribeiro
	 * @return nome
	 */
	public String getNomeAresta(String a) {
		
		return a.substring(0, a.indexOf("("));
	}

	
	/**
	 * Verifica se um determinado vertice existe no grafo
	 * @author alysson.l.ribeiro
	 * @return <b> true </b>, se existir. <b>false</b>, caso contr�rio.
	 */
	public boolean verticeExiste(String v) {
		
		boolean existe = false;
		
		for (String i:this.vertices) {
			if (v.equals(i)){
				existe = true;
				break;
			}
		}
		
		if (!existe) {
			String errorMsg = ("O vertice '"+ v +"' nao existe neste grafo.");
			throw new IllegalArgumentException(errorMsg);
		}
		
		return existe;
	}
	
	/**
	 * Verifica se a aresta informada corresponde ao padrao esperado pelo grafo
	 * @author alysson.l.ribeiro
	 */
	private boolean verificaAresta(String a){
		
		boolean valido = true;
		String errorMsg = null;

		// Contem o separador
		if (!a.contains("-")) {
			errorMsg = ("Aresta deve conter um separador (-) entre os vertices." +
					"Formato esperado: A-B");
			
			valido =  false;
		}
		
		String verticeOrigem = this.getVerticesAresta(a).get(0);
		String verticeDestino = this.getVerticesAresta(a).get(1);
		
		// Contem o vertice de origem
		if (verticeOrigem.isEmpty()) {
			errorMsg = ("Aresta deve conter um vertice de origem.");
			
			valido = false;
		}
		
		// Contem o vertice de destino
		if (verticeDestino.isEmpty()) {
			errorMsg = ("Aresta deve conter um vertice de destino.");
			
			valido = false; 
		}
		
		// Contem apenas um vertice de destino
		if (verticeDestino.contains("-")) {
			errorMsg = ("Aresta deve conter apenas um vertice de destino." +
					"O vertice de destino informado foi:" + verticeDestino);

			valido = false;
		}
		
		// Dispara erro em caso de ser invalido
		if  (!valido) throw new IllegalArgumentException(errorMsg);

		// Se nao cair em nenhuma das condicoes para retornar falso anteriormente, eh valido
		return true;
	}
	
	/**
	 * Verifica se a vertice informado corresponde ao padrao esperado pelo grafo
	 * @author alysson.l.ribeiro
	 */
	private boolean verificaValidadeVertice(String v) {
		boolean valido = true;
		
		if (v.contains(",")) valido = false;
		else if (v.contains(" ")) valido = false;
		else if (v.contains("(")) valido = false;
		else if (v.contains(")")) valido = false;
		
		// Dispara erro em caso de ser invalido
		if  (!valido) throw new IllegalArgumentException("Vertice invalido.");

		return valido;
	}
	
	/**
	 * Recupera pares de vertices que nao sao adjacentes / vizinhos
 	 * @author alysson.l.ribeiro
 	 * 3.A Roteiro 1
 	 * 
 	 * return List verticesNaoAdjacentes
	 */
	public List<String> getVerticesNaoAdjacentes() {

		List<String> verticesNaoAdjacentes =  new ArrayList<String>();
		
		// Verifica se o vertice ("i") do grafo
		for (int i = 0; i < this.getVertices().size() - 1; i++) {
			
			String verticeI = this.getVertices().get(i);

			// Em relacao a outro vertice ("j") do grafo
			for (int j = i + 1; j < this.getVertices().size(); j++) {
				
				String verticeJ = this.getVertices().get(j);

				boolean naoExisteNoVerticeI = true;
				boolean naoExisteNoVerticeJ = true;
				
				// Se o vertice "i" nao existir dentro das arestas do vertice "j" e vice versa, significa que não sao adjacentes
				for (String arestasVerticeI:this.getArestas(verticeI)) {
					if (getVerticesAresta(arestasVerticeI).contains(verticeJ)) {
						naoExisteNoVerticeI = false;
					}
				}
				
				for (String arestasVerticeJ:this.getArestas(verticeJ)) {
					if (getVerticesAresta(arestasVerticeJ).contains(verticeI)) {
						naoExisteNoVerticeJ = false;
					}					
				}

				// Significa que o vertice "i" nao eh adjacente em relacao ao vertice "j".
				if (naoExisteNoVerticeI && naoExisteNoVerticeJ) verticesNaoAdjacentes.add(vertices.get(i) + "-" + vertices.get(j));

			}
		}
		
		return verticesNaoAdjacentes;	
	}
	
	/**
	 * Recupera pares de vertices que nao sao adjacentes / vizinhos
 	 * @author alysson.l.ribeiro
 	 * 3.A Roteiro 1
 	 * 
 	 * return List verticesNaoAdjacentes
	 */
	public List<String> getVerticesNaoAdjacentesMatrizAdjacencia() {

		List<String> verticesNaoAdjacentes =  new ArrayList<String>();
				
		for (int i = 0; i < MatrizAdjacencia.length; i++) {
			for (int j = 0; j < i; j++) {

				if (this.MatrizAdjacencia[i][j] == 0) {
					verticesNaoAdjacentes.add(this.vertices.get(i) + "-" + this.vertices.get(j));
				}
			}
		}
				
		return verticesNaoAdjacentes;	
	}
	
	/**
	 * Verifica se um vertice informado tem adjacencia propria / loop
 	 * @author alysson.l.ribeiro
 	 * 3.B Roteiro 1
 	 * 
 	 * @return boolean true (se vertice tiver adjacencia propria) / false (caso contrario)
	 */
	public boolean verificaVerticeTemAdjacenciaPropria(String v) {
		
		boolean temAdjacenciaPropria = false;
		
		for (String a : this.getArestas(v)) {
			String verticeOrigem = this.getVerticesAresta(a).get(0);
			String verticeDestino = this.getVerticesAresta(a).get(1);
			
			if (verticeOrigem.equals(verticeDestino)) {
				
				temAdjacenciaPropria = true;
				break;
				
			}
		}
			
		return temAdjacenciaPropria;	
	}
	
	/**
	 * Verifica se um vertice informado tem adjacencia propria / loop
 	 * @author alysson.l.ribeiro
 	 * 
 	 * @return boolean true (se vertice tiver adjacencia propria) / false (caso contrario)
	 */
	public boolean verificaVerticeTemAdjacenciaPropriaMatrizAdjacencia(String v) {

		boolean temAdjacenciaPropria = false;
		int indiceDoVertice = this.vertices.indexOf(v);
		
		if (this.MatrizAdjacencia[indiceDoVertice][indiceDoVertice] > 0) {
			temAdjacenciaPropria = true;
		}
				
		return temAdjacenciaPropria;	
	}
	
	/**
	 * Verifica se o grafo tem arestas paralelas
	 * @author alysson.l.ribeiro
	 * 3.C Roteiro 1
	 * 
	 * @return boolean true (se o grafo tiver arestas paralelas) / false (caso contrario)
	 */
	public boolean verificaArestasParalelas() {
		
		boolean temArestasParalelas = false;
		
		// Verifica se a aresta ("i") do grafo
		for (int i = 0; i < this.arestas.size() - 1; i++) {

			String verticeOrigemA = this.getVerticesAresta(this.arestas.get(i)).get(0);
			String verticeDestinoA = this.getVerticesAresta(this.arestas.get(i)).get(1);
			
			// Em relacao a outra aresta ("j") do grafo
			for (int j = i + 1; j < this.arestas.size(); j++) {
				
				String verticeOrigemB = this.getVerticesAresta(this.arestas.get(j)).get(0);
				String verticeDestinoB = this.getVerticesAresta(this.arestas.get(j)).get(1);
				
				// Se as arestas tiverem os vertices equivalentes, o grafo tem arestas paralelas
				if (verticeOrigemA.equals(verticeDestinoB) && verticeOrigemB.equals(verticeDestinoA)) {
					temArestasParalelas = true;
					break;
				}
			}
			
			if (temArestasParalelas) {
				break;
			}
		}
		
		return temArestasParalelas;	
	}
	
	/**
	 * Verifica se o grafo tem arestas paralelas
	 * @author alysson.l.ribeiro
	 * 
	 * @return boolean true (se o grafo tiver arestas paralelas) / false (caso contrario)
	 */
	public boolean verificaArestasParalelasMatrizAdjacencia() {
		
		boolean temArestasParalelas = false;
		
		for (int i = 0; i < MatrizAdjacencia.length; i++) {
			
			for (int j = 0; j < i; j++) {	
				
				if (this.MatrizAdjacencia[i][j] > 1) {
					temArestasParalelas =  true;
					break;
				}
				
			}
			
			if (temArestasParalelas) {
				break;
			}
			
		}
		
		return temArestasParalelas;	
	}
	

	/**
	 * Verifica se o grafo tem arestas paralelas
	 * @author alysson.l.ribeiro
	 * 3.C.EXTRA Roteiro 1
	 * 
	 * @return boolean true (se o grafo tiver arestas paralelas) / false (caso contrario)
	 */
	public List<String> getArestasParalelas() {
		
		List<String> arestasParalelas =  new ArrayList<String>();
		
		// Verifica se a aresta ("i") do grafo
		for (int i = 0; i < this.arestas.size() - 1; i++) {

			String verticeOrigemA = this.getVerticesAresta(this.arestas.get(i)).get(0);
			String verticeDestinoA = this.getVerticesAresta(this.arestas.get(i)).get(1);
			
			// Em relacao a outra aresta ("j") do grafo
			for (int j = i + 1; j < this.arestas.size(); j++) {
				
				String verticeOrigemB = this.getVerticesAresta(this.arestas.get(j)).get(0);
				String verticeDestinoB = this.getVerticesAresta(this.arestas.get(j)).get(1);
				
				// Se as arestas tiverem os vertices equivalentes, o grafo tem arestas paralelas
				if (verticeOrigemA.equals(verticeDestinoB) && verticeOrigemB.equals(verticeDestinoA)) {
					arestasParalelas.add(this.arestas.get(i) + " com " + this.arestas.get(j));
				}
			}
		}
		
		return arestasParalelas;	
	}
	
	/**
	 * Verifica se o grafo tem arestas paralelas
	 * @author alysson.l.ribeiro
	 * 3.C.EXTRA Roteiro 1
	 * 
	 * @return boolean true (se o grafo tiver arestas paralelas) / false (caso contrario)
	 */
	public List<String> getArestasParalelasMatrizAdjacencia() {
		
		List<String> arestasParalelas =  new ArrayList<String>();
		
		for (int i = 0; i < MatrizAdjacencia.length; i++) {
			for (int j = 0; j <= i; j++) {

				if (this.MatrizAdjacencia[i][j] == 2) {
					
					arestasParalelas.add("(" + this.vertices.get(i) + "-" + this.vertices.get(j)+")" + " com "
							+ "(" + this.vertices.get(j) + "-" + this.vertices.get(i) + ")"
							);
					
				}
			}
		}
		
		return arestasParalelas;	
	}
	
	/**
	 * 
	 * Recupera o grau de um determinado vertice
	 * @author alysson.l.ribeiro
	 * 3.D Roteiro 1
	 * 
	 * @return int grauDoVertice
	 */
	public int getGrauDoVertice(String v) {
		
		int grau = this.getArestasIncidentes(v).size();
		
		return grau;
		
	}
	
	/**
	 * 
	 * Recupera o grau de um determinado vertice
	 * @author alysson.l.ribeiro
	 * Roteiro 2
	 * 
	 * @return int grauDoVertice
	 */
	public int getGrauDoVerticeMatrizAdjacencia(String v) {
		
		int grau = 0;
		
		for (int i = 0; i < MatrizAdjacencia.length; i++) {
			grau += MatrizAdjacencia[this.getVertices().indexOf(v)][i];
		}
		
		return grau;
	}
	
	/**
	 *
	 * Verifica quais arestas incidem sobre um vertice
	 * @author alysson.l.ribeiro
	 * 3.E Roteiro 1
	 *
	 */
	public List<String> getArestasIncidentes(String v) {
		
		List<String> arestasIncidentes =  new ArrayList<String>();
		
		// Verifica para cada aresta do grafo
		for (String aresta:this.getArestas()) {
			
			// Se o vertice é ponto de conexao dela. Se for igual, eh porque a aresta incide sobre o vertice
			if (this.getVerticesAresta(aresta).contains(v)) {
				arestasIncidentes.add(aresta);
			}

		}
		
		return arestasIncidentes;	
	}
	
	/**
	 *
	 * Verifica se o grafo eh completo. Se nao tem arestas nao adjacentes
	 * @author alysson.l.ribeiro
	 * 3.F Roteiro 1
	 *
	 * @return boolean true (se grafor for completo) / false (caso contrario)
	 */
	public boolean verificaGrafoCompleto() {
		
		boolean ehGrafoCompleto;
		
		if(this.getVerticesNaoAdjacentes().size() == 0) {
			ehGrafoCompleto = true;
		} else {
			ehGrafoCompleto = false;
		}
		
		return ehGrafoCompleto;
		
	}
	
	/**
	 *
	 * Verifica se o grafo eh completo. Se nao tem arestas nao adjacentes
	 * @author alysson.l.ribeiro
	 *
	 * @return boolean true (se grafor for completo) / false (caso contrario)
	 */
	public boolean verificaGrafoCompletoMatrizAdjacencia() {
		
		boolean ehGrafoCompleto;
		
		if(this.getVerticesNaoAdjacentesMatrizAdjacencia().size() == 0) {
			ehGrafoCompleto = true;
		} else {
			ehGrafoCompleto = false;
		}
		
		return ehGrafoCompleto;
		
	}
	
	/**
	 * @param tamanho
	 * @return
	 */
	public String getCaminhoDeTamanho(int tamanho) {
		
		List<String> caminho = new ArrayList<String>();
		
		// Se o tamanho solicitado for maior que a quantidade de arestas, nao vai ser possivel recuperar um caminho do tamanho desejado
		// Para poupar processamento, ja anula o caso de inicio
		if (tamanho > this.getArestas().size()) {
			return "false";
		} else {
			
			// Verifica para todos os vertices se consegue encontrar um caminho do tamanho desejado
			for (String vertice:this.getVertices()) {
				
				caminho = percorreCaminhoTamanho(tamanho, caminho, vertice, this.getArestas());
				
				if (caminho.size() == tamanho) {
					break;
				}
			}
			
		}
		
		String retorno = caminho.size() == tamanho ? caminho.toString() : "false";
		
		return retorno;
		
	}
	
	/**
	 * @param tamanho
	 * @param caminho
	 * @param verticeAtual
	 * @param arestasDisponiveis
	 * @return
	 */
	public List<String> percorreCaminhoTamanho(int tamanho, List<String> caminho, String verticeAtual, List<String> arestasDisponiveis) {
		
		List<String> arestasIncidentesVertice = this.getArestasIncidentes(verticeAtual);
		List<String> arestasDisponiveisTmp = arestasDisponiveis;
		List<String> caminhoTmp = caminho;		
		
		if (caminhoTmp.size() == tamanho || arestasDisponiveisTmp.isEmpty()) {
		
			return caminhoTmp;
		
		} else {
			
			// Deixa nas arestas incidentes apenas as arestas disponiveis
			for (String aresta:arestasIncidentesVertice) {
				
				if (!arestasDisponiveisTmp.contains(aresta)) {
					
					// DELETA A ARESTA INCIDENTE, CASO ELA NAO ESTEJA DISPONIVEL
					arestasIncidentesVertice.remove(aresta);
				}
			
			}
			

			// NAVEGA PARA O PROXIMO VERTICE, CASO EXISTA
			String verticeDestino = "";

			for (String aresta:arestasIncidentesVertice) {
			
				String verticeA = this.getVerticesAresta(aresta).get(0);
				String verticeB = this.getVerticesAresta(aresta).get(1);
				
				if(!verticeA.equals(verticeAtual)) {
					
					verticeDestino = verticeA;
						
				} else {
					
					verticeDestino = verticeB;
				
				}
		
				arestasDisponiveisTmp.remove(aresta);
				caminhoTmp.add(aresta);
				percorreCaminhoTamanho(tamanho, caminhoTmp, verticeDestino, arestasDisponiveisTmp);
				
				if (caminhoTmp.size() == tamanho || arestasDisponiveisTmp.isEmpty()) {
					
					return caminhoTmp;
					
				}
			
			}
			
			// SE PARAR POR NAO ENCONTRAR MAIS ARESTAS INDICENTES DISPONIVEIS, DESCONSIDERAR ULTIMO CAMINHO PERCORRIDO
			if (arestasIncidentesVertice.isEmpty()) {
				caminhoTmp.remove(caminhoTmp.size()-1);
			}

		
		}
		
		return caminhoTmp;
		
	}
	
	/**
	 * DESAFIO 3.G
	 * @param tamanho
	 * @return
	 */
	public String getCaminhoDeCiclo() {
		
		List<String> caminho = new ArrayList<String>();
			
		// Verifica para todos os vertices se consegue encontrar um ciclo que saia dele e termine nele
		for (String vertice:this.getVertices()) {			
			
			caminho = percorreCaminhoCiclo(caminho, vertice, this.getArestas(), 0);
			
		}
			
		return caminho.size() > 0 ? caminho.toString() : "false";
		
	}
	
	/**
	 * TODO
	 * @param caminho
	 * @param verticeAtual
	 * @param arestasDisponiveis
	 * @param ocorrenciasDeVertice
	 * @return
	 */
	public List<String> percorreCaminhoCiclo(List<String> caminho, String verticeAtual, List<String> arestasDisponiveis, int ocorrenciasDeVertice) {
		
		List<String> arestasIncidentesVertice = this.getArestasIncidentes(verticeAtual);
		List<String> arestasDisponiveisTmp = arestasDisponiveis;
		List<String> caminhoTmp = caminho;		
		ocorrenciasDeVertice = this.contaOcorrenciasDeVerticeNoCaminho(caminhoTmp.toString(), verticeAtual);
		
		if (ocorrenciasDeVertice >= 2 || arestasDisponiveisTmp.isEmpty()) {
		
			return caminhoTmp;
		
		} else {
			
			// Deixa nas arestas incidentes apenas as arestas disponiveis
			for (String aresta:arestasIncidentesVertice) {
				
				if (!arestasDisponiveisTmp.contains(aresta)) {
					// DELETA A ARESTA INCIDENTE, CASO ELA NAO ESTEJA DISPONIVEL
					arestasIncidentesVertice.remove(aresta);
				}
				
			}
			

			// NAVEGA PARA O PROXIMO VERTICE, CASO EXISTA
			String verticeDestino = "";

			for (String aresta:arestasIncidentesVertice) {
			
				String verticeA = this.getVerticesAresta(aresta).get(0);
				String verticeB = this.getVerticesAresta(aresta).get(1);
				
				if(!verticeA.equals(verticeAtual)) {
					verticeDestino = verticeA;
				} else {
					verticeDestino = verticeB;
				}
		
				arestasDisponiveisTmp.remove(aresta);
				caminhoTmp.add(aresta);
				percorreCaminhoCiclo(caminhoTmp, verticeDestino, arestasDisponiveisTmp, ocorrenciasDeVertice);
								
				if (ocorrenciasDeVertice >= 2 || arestasDisponiveisTmp.isEmpty()) {
					return caminhoTmp;
				}
			
			}
			
			// SE PARAR POR NAO ENCONTRAR MAIS ARESTAS INDICENTES DISPONIVEIS, DESCONSIDERAR ULTIMO CAMINHO PERCORRIDO
			if (arestasIncidentesVertice.isEmpty()) {
				caminhoTmp.remove(caminhoTmp.size()-1);
			}

		
		}
		
		return caminhoTmp;
		
	}
	
	/**
	 * funcao auxiliar ao desafio 3.G
	 * @param caminho
	 * @param vertice
	 * @return
	 */
	public int contaOcorrenciasDeVerticeNoCaminho (String caminho, String vertice) {
		
	    int count = 0;
	    
	    for (int i = 0; i < caminho.length(); i++) {
	    	
	        if (caminho.subSequence(i, i + vertice.length()).equals(vertice)) {
	             count++;
	        }
	        
	    }
	    
	    return count;
	}
	
	/**
	 * Verifica se grafo tem Caminho Euleriano
	 * @author Alysson Ribeiro
	 *  
	 */
	public boolean verificaCaminhoEuleriano() {
		
		boolean temCaminhoEuleriano = false;
		boolean grafoConexo = false;
		
		// VERIFICA SE GRAFO EH CONEXO
		grafoConexo = this.verificaGrafoConexo();
		
		if (grafoConexo) {
		
			temCaminhoEuleriano = true;		
			int totalVerticesImpares = 0;
			
			for (int i = 0; i < MatrizAdjacencia.length; i++) {
				
				if (totalVerticesImpares == 2) {
					temCaminhoEuleriano = true;
					break;
				}
				
				if (this.getGrauDoVerticeMatrizAdjacencia(this.vertices.get(i)) % 2 > 1) {
					totalVerticesImpares += 1;
					temCaminhoEuleriano = false;
				};
				
			}
			
			if (temCaminhoEuleriano) {
				System.out.println("Existe um caminho euleriano.");
			} else {
				System.out.println("Nao existe caminho euleriano.");
			}

		}
		
		return temCaminhoEuleriano;
		
	}
	
	/**
	 * Verifica se grafo eh conexo
	 * @author Alysson Ribeiro
	 * @return
	 * 
	 * TODO
	 */
	public boolean verificaGrafoConexo() {
		
		boolean grafoConexo = true;
		boolean[][] matrizAlcancabilidade = this.getMatrizAlcancabilidadeWarshall();
		
		for (int i = 0; i < matrizAlcancabilidade.length; i++) {
			
			grafoConexo = false;
			
			for (int j = i; j < matrizAlcancabilidade.length; j++) {
				if((i != j) && (matrizAlcancabilidade[i][j] == true)) {
					grafoConexo = true;
				}
				
			}
			
			if (!grafoConexo) {
				break;
			}
		}	
		
		return grafoConexo;
	}
	
	/**
	 * Warshall
	 * @author Alysson Ribeiro
	 * @return
	 */
	public boolean[][] getMatrizAlcancabilidadeWarshall(){

		boolean[][] MatrizAlcancabilidade = new boolean[MatrizAdjacencia.length][MatrizAdjacencia.length];
		
        int i, j, k;
        
        // inicializa��o da matriz
        for (i = 0; i < this.MatrizAdjacencia.length; i++) {
            for (j = 0; j < this.MatrizAdjacencia.length; j++) {
            	MatrizAlcancabilidade[i][j] = (this.MatrizAdjacencia[i][j] > 0);
            }
        }
        
        // algoritmo de Warshall
        for (k = 0; k < this.MatrizAdjacencia.length; k++) {
            for (i = 0; i < this.MatrizAdjacencia.length; i++) {
                if (MatrizAlcancabilidade[i][k]) {
                    for (j = 0; j < this.MatrizAdjacencia.length; j++) {
                    	MatrizAlcancabilidade[i][j] = (MatrizAlcancabilidade[i][j] || MatrizAlcancabilidade[k][j]);
                    }
                }
            }
        }
        
		return MatrizAlcancabilidade;
		
	}
	

	/**
	 * DIJKSTRA
	 * @param verticeOrigem
	 * @param verticeDestino
	 * @return
	 * 
	 * TODO
	 */
	//metodo que retorna o caminho menos custoso entre dois vertices a partid do algoritmo de Dijkstra
//    public List<String> encontrarMenorCaminhoDijkstra(String verticeOrigem,String verticeDestino) {
//
//    	// Atributos usados na funcao encontrarMenorCaminho
//
//        // Lista que guarda os vertices pertencentes ao menor caminho encontrado
//    	List<String> menorCaminho = new ArrayList<String>();
//        // Variavel que recebe os vertices pertencentes ao menor caminho
//        String verticeCaminho;
//        // Variavel que guarda o vertice que esta sendo visitado
//        String verticeAtual;
//        // Variavel que marca o vizinho do vertice atualmente visitado
//        String verticeVizinho;
//        
//        // Aresta que liga o atual ao seu vizinho;
//        String arestaLigacao;
//
//        // Lista dos vertices que ainda nao foram visitados
//        List<String> naoVisitados = new ArrayList<String>();
//
//        // Algoritmo de Dijkstra
//        
//    	// Adiciona a origem na lista do menor caminho
//        menorCaminho.add(verticeOrigem);
//
//        // Colocando a distancias iniciais 
//        for (int i = 0; i < this.getVertices().size(); i++) {
//            // Vertice atual tem distancia zero, e todos os outros,
//            // 9999("infinita")
//            if (this.getVertices().get(i).getNome().equals(verticeOrigem.getNome()))
//                this.getVertices().get(i).setDistancia(0);
//            else
//                this.getVertices().get(i).setDistancia(9999);
//            // Insere o vertice na lista de vertices nao visitados
//            naoVisitados.add(this.getVertices().get(i));
//        }
//
//        Collections.sort(naoVisitados);
//
//        // O algoritmo continua ate que todos os vertices sejam visitados
//        while (!naoVisitados.isEmpty()) {
//            // Toma-se sempre o vertice com menor distancia, que eh o primeiro
//            // da
//            // lista
//
//            verticeAtual = naoVisitados.get(0);
//            /*
//             * Para cada vizinho (cada aresta), calcula-se a sua possivel
//             * distancia, somando a distancia do vertice atual com a da aresta
//             * correspondente. Se essa distancia for menor que a distancia do
//             * vizinho, esta eh atualizada.
//             */
//            for (int i = 0; i < verticeAtual.getVizinhos().size(); i++) {
//            	
//                verticeVizinho = verticeAtual.getVizinhos().get(i);
//                
//                if (!verticeVizinho.isVisitado()) {
//                	
//                    // Comparando a dist�ncia do vizinho com a poss�vel
//                    // dist�ncia
//                	arestaLigacao = this.acharAresta(verticeAtual,verticeVizinho);
//                    if (verticeVizinho.getDistancia() > (verticeAtual.getDistancia() + arestaLigacao.getPeso())) {
//                        verticeVizinho.setDistancia(verticeAtual.getDistancia()
//                                        + arestaLigacao.getPeso());
//                        verticeVizinho.setPai(verticeAtual);
//
//                        /*
//                         * Se o vizinho eh o vertice procurado, e foi feita uma
//                         * mudanca na distancia, a lista com o menor caminho
//                         * anterior eh apagada, pois existe um caminho menor
//                         * vertices pais, ateh o vertice origem.
//                         */
//                        if (verticeVizinho == verticeDestino) {
//                            menorCaminho.clear();
//                            verticeCaminho = verticeVizinho;
//                            menorCaminho.add(verticeVizinho);
//                            while (verticeCaminho.getPai() != null) {
//                                menorCaminho.add(verticeCaminho.getPai());
//                                verticeCaminho = verticeCaminho.getPai();
//
//                            }
//                            // Ordena a lista do menor caminho, para que ele
//                            // seja exibido da origem ao destino.
//                            Collections.sort(menorCaminho);
//
//                        }
//                    }
//                }
//
//            }
//            // Marca o vertice atual como visitado e o retira da lista de nao
//            // visitados
//            verticeAtual.setVisitado(true);
//            naoVisitados.remove(verticeAtual);
//            /*
//             * Ordena a lista, para que o vertice com menor distancia fique na
//             * primeira posicao
//             */
//
//            Collections.sort(naoVisitados);
//
//        }
//        this.limparVerticesPai();
//        return menorCaminho;
//    }

	@Override
	public String toString() {
		return "Grafo [vertices=" + vertices + ", arestas=" + arestas + ", MatrizAdjacencia="
				+ Arrays.toString(MatrizAdjacencia) + "]";
	}

}
