package br.edu.ifpb;

import java.io.Serializable;

import br.edu.ifpb.dominio.Zoológico;

public class GeradorIdNanotime implements Serializable {

	private static final long serialVersionUID = 1L;

	public Long recuperarProximoId(Zoológico zoo) {
		return System.nanoTime();
	}
	
}
