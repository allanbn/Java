package br.edu.ifpb.cg.q3.dominio;

public interface temRepresentacaoTextual {

    String produtoTexto();

}
