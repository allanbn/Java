/**
 * 
 */
package main;

import java.util.Scanner;
import domain.Grafo;

/**
 * @author alysson.l.ribeiro
 *
 */
public class Main {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		
		/* DADOS UTILIZADOS COMO PARAMETROS DE TESTE:
		 * 
		 * VERTICES:
		 * A, B, C, D, E
		 * 
		 * ARESTAS:
		 * a1(A-B), a2(A-C), a3(A-A), b1(B-A), b2(B-C), b3(B-D), c1(C-A), c2(C-D), d1(D-B), d2(D-C), e1(E-E)  
		 * 
		 */
		
		// CONSTROI O GRAFO A PARTIR DOS VALORES INFORMADOS
		
		@SuppressWarnings("resource")		
		Scanner sc = new Scanner(System.in);
		long execStartTime;
		long execEndTime; 
		String v;

		System.out.println("Insira os vertices do grafo que voce deseja criar:");
		String[] vertices = sc.nextLine().split(",");	    
		
	    System.out.println("---");
		System.out.println("Insira as arestas do grafo que voce deseja criar:");
	    String[] arestas = sc.nextLine().split(",");
	    
		Grafo g = new Grafo(vertices, arestas);

	    // GRAFO CRIADO
	    System.out.println("---");
	    System.out.println("Grafo criado:");
	    System.out.println(g.toString());
	    
	    // ARESTAS DO GRAFO
	    System.out.println("---");
	    System.out.println("Arestas do grafo:");
	    System.out.println(g.getArestas().toString());

	    // VERTICES DO GRAFO
	    System.out.println("---");
	    System.out.println("Vertices do grafo:");
	    System.out.println(g.getVertices().toString());
	    
	    //MATRIZ ADJACENCIA
	    System.out.println("---");
	    System.out.println("Matriz de adjacencia do grafo:");
		execStartTime = System.nanoTime();
	    int[][] matriz = g.getMatrizAdjacencia();
	    
	    for (int i = 0; i < g.getVertices().size(); i++) {

	    	System.out.printf("LINHA " + g.getVertices().get(i) + ": ");

	        
	        for (int j = 0; j < g.getVertices().size(); j++) {
	          System.out.printf("%d ", matriz[i][j]);
	        }
	        
	        System.out.printf("\n");
	    }
	    
		execEndTime = System.nanoTime();
		System.out.println("Funcao executada em <"+ (execEndTime - execStartTime) + "ns>");
	    
	    // MATRIZ DE ALCAN�ABILIDADE
	    System.out.println("---");
	    System.out.println("Matriz de Alcancabilidade (Warshall):");
	    execStartTime = System.nanoTime();
	    boolean[][] matrizAlcancabilidade = g.getMatrizAlcancabilidadeWarshall();
	    
	    for (int i = 0; i < g.getVertices().size(); i++) {
	        System.out.printf("LINHA " + g.getVertices().get(i) + ": ");

	        
	        for (int j = 0; j < g.getVertices().size(); j++) {
	          System.out.printf("%b ", matrizAlcancabilidade[i][j]);
	        }
	        
	        System.out.printf("\n");
	    }
	    
		execEndTime = System.nanoTime();
		System.out.println("Funcao executada em <"+ (execEndTime - execStartTime) + "ns>");	    
	    
		// VERTICES NAO ADJACENTES
	    System.out.println("---");
	    System.out.println("Vertices nao adjacentes:");
	    execStartTime = System.nanoTime();
	    System.out.println(g.getVerticesNaoAdjacentes().toString());
		execEndTime = System.nanoTime();
		System.out.println("Funcao executada em <"+ (execEndTime - execStartTime) + "ns>");	 
	    System.out.println("---");
	    System.out.println("Vertices nao adjacentes (Matriz Adjacencia):");
	    execStartTime = System.nanoTime();
	    System.out.println(g.getVerticesNaoAdjacentesMatrizAdjacencia().toString());
		execEndTime = System.nanoTime();
		System.out.println("Funcao executada em <"+ (execEndTime - execStartTime) + "ns>");	 

	    // ADJACENCIA PROPRIA
	    System.out.println("---");
	    System.out.println("Digite um vertice para verificar se ele tem adjacencia propria:");
	    v = sc.nextLine().trim();
	    execStartTime = System.nanoTime();
	    System.out.println(g.verificaVerticeTemAdjacenciaPropria(v));
		execEndTime = System.nanoTime();
		System.out.println("Funcao executada em <"+ (execEndTime - execStartTime) + "ns>");	 
	    System.out.println("---");
	    System.out.println("Verifica se vertice tem adjacencia propria (Matriz Adjacencia):");
	    execStartTime = System.nanoTime();
	    System.out.println(g.verificaVerticeTemAdjacenciaPropriaMatrizAdjacencia(v));
		execEndTime = System.nanoTime();
		System.out.println("Funcao executada em <"+ (execEndTime - execStartTime) + "ns>");	
	    
	    // ARESTAS PARALELAS
	    System.out.println("---");
	    System.out.println("Grafo tem arestas paralelas?");
	    execStartTime = System.nanoTime();
	    System.out.println(g.verificaArestasParalelas());
		execEndTime = System.nanoTime();
		System.out.println("Funcao executada em <"+ (execEndTime - execStartTime) + "ns>");	
	    System.out.println("---");
	    System.out.println("Grafo tem arestas paralelas? (Matriz Adjacencia)");
	    execStartTime = System.nanoTime();
	    System.out.println(g.verificaArestasParalelasMatrizAdjacencia());
		execEndTime = System.nanoTime();
		System.out.println("Funcao executada em <"+ (execEndTime - execStartTime) + "ns>");	

	    // 3C.EXTRA ARESTAS PARALELAS
	    System.out.println("---");
	    System.out.println("As arestas paralelas sao:");
	    execStartTime = System.nanoTime();
	    System.out.println(g.getArestasParalelas());
		execEndTime = System.nanoTime();
		System.out.println("Funcao executada em <"+ (execEndTime - execStartTime) + "ns>");	
	    System.out.println("---");
	    System.out.println("As arestas paralelas sao (Matriz Adjacencia):");
	    execStartTime = System.nanoTime();
	    System.out.println(g.getArestasParalelasMatrizAdjacencia());
		execEndTime = System.nanoTime();
		System.out.println("Funcao executada em <"+ (execEndTime - execStartTime) + "ns>");	
	    
	    // 3D GRAU DO VERTICE
	    System.out.println("---");
	    System.out.println("Digite um vertice para verificar o grau dele:");
	    v = sc.nextLine().trim();
	    execStartTime = System.nanoTime();
	    System.out.println(g.getGrauDoVertice(v));
		execEndTime = System.nanoTime();
		System.out.println("Funcao executada em <"+ (execEndTime - execStartTime) + "ns>");	
	    System.out.println("---");
	    System.out.println("O grau dele (Matriz de Adjacencia):");
	    execStartTime = System.nanoTime();
	    System.out.println(g.getGrauDoVerticeMatrizAdjacencia(v));
		execEndTime = System.nanoTime();
		System.out.println("Funcao executada em <"+ (execEndTime - execStartTime) + "ns>");	

	    // 3E ARESTAS INCIDENTES
	    System.out.println("---");
	    System.out.println("Digite um vertice para recuperar as arestas incidentes a ele:");
	    v = sc.nextLine().trim();
	    execStartTime = System.nanoTime();
	    System.out.println(g.getArestasIncidentes(v));
	    execEndTime = System.nanoTime();
		System.out.println("Funcao executada em <"+ (execEndTime - execStartTime) + "ns>");	

	    // 3F GRAFO COMPLETO
	    System.out.println("---");
	    System.out.println("Grafo completo?");
	    execStartTime = System.nanoTime();
	    System.out.println(g.verificaGrafoCompleto());
	    execEndTime = System.nanoTime();
		System.out.println("Funcao executada em <"+ (execEndTime - execStartTime) + "ns>");	
	    System.out.println("---");
	    System.out.println("Grafo completo (Matriz Adjacencia)?");
	    execStartTime = System.nanoTime();
	    System.out.println(g.verificaGrafoCompletoMatrizAdjacencia());	 
	    execEndTime = System.nanoTime();
		System.out.println("Funcao executada em <"+ (execEndTime - execStartTime) + "ns>");	
	    
	    // CAMINHO
	    System.out.println("---");
	    System.out.println("Digite um tamanho de caminho a ser recuperado neste grafo (caso exista):");
	    int n = sc.nextInt();
	    execStartTime = System.nanoTime();
	    System.out.println(g.getCaminhoDeTamanho(n));
	    execEndTime = System.nanoTime();
		System.out.println("Funcao executada em <"+ (execEndTime - execStartTime) + "ns>");	
	    
	    // CAMINHO CICLO
	    System.out.println("---");
	    System.out.println("Ciclo?");
	    execStartTime = System.nanoTime();
	    System.out.println(g.getCaminhoDeCiclo());
	    execEndTime = System.nanoTime();
		System.out.println("Funcao executada em <"+ (execEndTime - execStartTime) + "ns>");	
	    
	    // GRAFO CONEXO
	    System.out.println("---");
	    System.out.println("Grafo conexo?");
	    execStartTime = System.nanoTime();
	    System.out.println(g.verificaGrafoConexo());
	    execEndTime = System.nanoTime();
		System.out.println("Funcao executada em <"+ (execEndTime - execStartTime) + "ns>");	
	    
	    // CAMINHO EULERIANO
	    System.out.println("---");
	    System.out.println("Caminho Euleriano?");
	    execStartTime = System.nanoTime();
	    System.out.println(g.verificaCaminhoEuleriano());
	    execEndTime = System.nanoTime();
		System.out.println("Funcao executada em <"+ (execEndTime - execStartTime) + "ns>");	
	    
//	    // CAMINHO DE DIJKSTRA
//	    System.out.println("---");
//	    System.out.println("Caminho mais curto (Dijkstra):");
	    
//	    sc.close();
	}

}
