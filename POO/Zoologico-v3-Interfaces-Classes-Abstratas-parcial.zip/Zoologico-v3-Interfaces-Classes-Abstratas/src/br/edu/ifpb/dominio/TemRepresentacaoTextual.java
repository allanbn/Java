package br.edu.ifpb.dominio;

public interface TemRepresentacaoTextual {

	public String obterRepresentacaoTextual();
	
}
