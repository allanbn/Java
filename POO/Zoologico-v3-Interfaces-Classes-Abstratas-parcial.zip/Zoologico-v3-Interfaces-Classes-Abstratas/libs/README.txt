1) Dependência Xstream obtida em: 
	* http://repo1.maven.org/maven2/com/thoughtworks/xstream/xstream-distribution/1.4.11.1/xstream-distribution-1.4.11.1-bin.zip
	* Página da biblioteca: http://x-stream.github.io/ 

2) Dependência Genson obtida em:
	* http://repo1.maven.org/maven2/com/owlike/genson/1.4/genson-1.4.jar
	* Página da biblioteca: http://genson.io/