package br.edu.ifpb.menu;

import br.edu.ifpb.exceptions.ZooException;

public interface Menu {

	public boolean exibirMenu() throws ZooException;
	
}
